package frontend.Syntax.Children;

import frontend.Lexer.Lexer.Token;
import frontend.Syntax.Syntax;

public class LAndExp {
    static void LAndExpAnalysis(int expsize) {
        int size = 1;
        int count = CompUnit.count + 2;
        if (Tools.LookNextTK().tk.equals("NOT")) { // jump "!"
            size++;
            count++;
        }

        for (; count - CompUnit.count < expsize;) {
            Token token = Tools.GetCountTK(count);
            if (!token.tk.equals("AND")) {
                size += 2;

            } else if (token.tk.equals("AND")) {
                EqExp.EqExpAnalysis(size);

                Tools.WriteLine(Syntax.NodeType.LAndExp, Tools.GetNowTK().id);
                CompUnit.count++; // &&
                size = 1;
            }
            count += 2;

            if (Tools.GetCountTK(count - 1).tk.equals("NOT")) { // jump "!"
                size++;
                count++;
            }
        }
        EqExp.EqExpAnalysis(size);
        Tools.WriteLine(Syntax.NodeType.LAndExp, Tools.GetNowTK().id);
    }
}
