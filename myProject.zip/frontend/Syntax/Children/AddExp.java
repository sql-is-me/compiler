package frontend.Syntax.Children;

import frontend.Lexer.Lexer.Token;
import frontend.Syntax.Syntax;

public class AddExp {
    static void AddExpAnalysis() {
        int count = CompUnit.count + 2; // 直接跳一位看符号
        int size = 1; // Mul表达式的长度
        if (Tools.LookNextTK().tk.equals("NOT")) { // jump "!"
            size++;
            count++;
        }

        while (Tools.GetCountTK(count).tk.equals("PLUS") || Tools.GetCountTK(count).tk.equals("MINU")
                || Tools.GetCountTK(count).tk.equals("MULT") || Tools.GetCountTK(count).tk.equals("DIV")
                || Tools.GetCountTK(count).tk.equals("MOD")) { //
            if (!Tools.GetCountTK(count).tk.equals("PLUS")
                    && !Tools.GetCountTK(count).tk.equals("MINU")) {
                size += 2;
            } else if (Tools.GetCountTK(count).tk.equals("PLUS")
                    || Tools.GetCountTK(count).tk.equals("MINU")) {
                MulExp.MulExpAnalysis(size);

                Tools.WriteLine(Syntax.NodeType.AddExp, Tools.GetNowTK().id);
                CompUnit.count++; // 踩在+ - ;上
                size = 1;
            }
            count += 2;

            if (Tools.GetCountTK(count - 1).tk.equals("NOT")) { // jump "!"
                size++;
                count++;
            }
        }
        MulExp.MulExpAnalysis(size);
        Tools.WriteLine(Syntax.NodeType.AddExp, Tools.GetNowTK().id);
    }

    static void AddExpAnalysis(int expsize) {
        int size = 1;
        int count = CompUnit.count + 2;

        if (Tools.LookNextTK().tk.equals("NOT")) { // jump "!"
            size++;
            count++;
        }

        for (; count - CompUnit.count < expsize;) {
            Token token = Tools.GetCountTK(count);
            if (!token.tk.equals("PLUS") && !token.tk.equals("MINU")) {
                size += 2;
            } else if (token.tk.equals("PLUS") || token.tk.equals("MINU")) {
                MulExp.MulExpAnalysis(size);

                Tools.WriteLine(Syntax.NodeType.AddExp, Tools.GetNowTK().id);
                CompUnit.count++; // + -
                size = 1;
            }
            count += 2;

            if (Tools.GetCountTK(count - 1).tk.equals("NOT")) { // jump "!"
                size++;
                count++;
            }
        }
        MulExp.MulExpAnalysis(size);
        Tools.WriteLine(Syntax.NodeType.AddExp, Tools.GetNowTK().id);
    }
}
