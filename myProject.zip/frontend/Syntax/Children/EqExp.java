package frontend.Syntax.Children;

import frontend.Lexer.Lexer.Token;
import frontend.Syntax.Syntax;

public class EqExp {
    static void EqExpAnalysis(int expsize) {
        int size = 1;
        int count = CompUnit.count + 2;
        if (Tools.LookNextTK().tk.equals("NOT")) { // jump "!"
            size++;
            count++;
        }

        for (; count - CompUnit.count < expsize;) {
            Token token = Tools.GetCountTK(count);
            if (!token.tk.equals("EQL") && !token.tk.equals("NEQ")) {
                size += 2;

            } else if (token.tk.equals("EQL") || token.tk.equals("NEQ")) {
                RelExp.RelExpAnalysis(size);

                Tools.WriteLine(Syntax.NodeType.EqExp, Tools.GetNowTK().id);
                CompUnit.count++; // == !=
                size = 1;
            }
            count += 2;

            if (Tools.GetCountTK(count - 1).tk.equals("NOT")) { // jump "!"
                size++;
                count++;
            }
        }
        RelExp.RelExpAnalysis(size);
        Tools.WriteLine(Syntax.NodeType.EqExp, Tools.GetNowTK().id);
    }
}
