package frontend.Syntax.Children;

public class BType {
    static void BTypeAnalysis() {
        CompUnit.count++;
    }
}