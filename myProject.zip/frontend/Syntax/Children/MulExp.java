package frontend.Syntax.Children;

import frontend.Lexer.Lexer.Token;
import frontend.Syntax.Syntax;

public class MulExp {
    static void MulExpAnalysis(int expsize) {
        int count = CompUnit.count + 2;
        if (Tools.LookNextTK().tk.equals("NOT")) { // jump "!"
            count++;
        }

        for (; count - CompUnit.count < expsize;) {
            Token token = Tools.GetCountTK(count);
            if (token.tk.equals("MULT")
                    || token.tk.equals("DIV")
                    || token.tk.equals("MOD")) {
                UnaryExp.UnaryExpAnalysis();

                Tools.WriteLine(Syntax.NodeType.MulExp, Tools.GetNowTK().id);
                CompUnit.count++; // 踩在* / % 上
            }
            count += 2;

            if (Tools.GetCountTK(count - 1).tk.equals("NOT")) { // jump "!"
                count++;
            }
        }
        UnaryExp.UnaryExpAnalysis();
        Tools.WriteLine(Syntax.NodeType.MulExp, Tools.GetNowTK().id);
    }
}
